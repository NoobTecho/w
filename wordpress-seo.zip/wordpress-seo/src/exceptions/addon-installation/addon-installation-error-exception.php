<?php

namespace Yoast\WP\SEO\Exceptions\Addon_Installation;

use Exception;

/**
 * Class Addon_Installation_Error
 */
class Addon_Installation_Error_Exception extends Exception {}
